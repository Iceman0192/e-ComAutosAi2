# ECOMAUTOS Project Export

This archive contains the complete ECOMAUTOS vehicle auction intelligence platform with authentic branding implementation.

## Contents:
- package.json - Project dependencies
- tailwind.config.ts - Tailwind configuration with ECOMAUTOS brand colors
- vite.config.ts - Vite build configuration
- components.json - shadcn/ui configuration
- postcss.config.js - PostCSS configuration
- client/src/App.tsx - Main application component
- client/src/index.css - Global styles with ECOMAUTOS branding
- client/src/components/ - All React components with authentic logo
- client/src/pages/ - Application pages (dashboard, auth, landing)
- client/src/contexts/ - React contexts for auth and usage
- client/src/lib/ - Utility libraries
- client/src/hooks/ - Custom React hooks
- shared/ - Database schema and shared types
- server/ - Backend API and services
- attached_assets/IMG_4870.jpg - Authentic ECOMAUTOS logo

## Key Features:
- Authentic ECOMAUTOS logo implementation throughout platform
- Premium styling with gold/silver color scheme
- Role-based authentication system
- Stripe payment integration
- Real-time auction data processing
- AI-powered vehicle analytics

## Installation:
1. Extract files to project directory
2. Install dependencies with package manager
3. Set up PostgreSQL database
4. Configure environment variables
5. Start development server

Brand Colors:
- Primary Gold: #FACC15
- Secondary Orange: #F97316  
- Silver/White: #F8FAFC
- Dark Slate: #1E293B
